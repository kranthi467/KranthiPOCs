﻿namespace Model
{
    /// <summary>
    /// A model for LogIn details
    /// </summary>
    public class LogInModel
    {
        public string userName;
        public string password;
    }
}
