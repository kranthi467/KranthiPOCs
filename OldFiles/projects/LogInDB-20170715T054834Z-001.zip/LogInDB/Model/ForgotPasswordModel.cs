﻿namespace Model
{
    /// <summary>
    /// A model for password retrival details
    /// </summary>
    public class ForgotPasswordModel
    {
        public string userName;
        public string phoneNo;
    }
}
