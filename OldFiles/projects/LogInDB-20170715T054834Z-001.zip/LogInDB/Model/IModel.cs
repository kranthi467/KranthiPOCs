﻿namespace Model
{
    public interface IModel
    {
    }
}
