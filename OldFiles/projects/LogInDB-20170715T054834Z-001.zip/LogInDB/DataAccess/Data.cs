﻿using Model;
using System.Data.SqlClient;

namespace DataAccess
{
    /// <summary>
    /// class to store and retrive data of users
    /// </summary>
    internal class Data : IData
    {

        SqlConnection con = new SqlConnection("Data Source=192.168.169.40;Initial Catalog=LogInApp;Persist Security Info=True;User ID=sa;Password=Dbase!2");

        /// <summary>
        /// A method to check wheather user is available or not
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool CheckUser(string userName)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "select USERNAME from UserDetails where USERNAME='" + userName + "';";
            command.ExecuteNonQuery();
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    con.Close();
                    return true;
                }
            }
            con.Close();
            return false;
        }

        /// <summary>
        /// A method to store user details. If sucessful returns True
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        public bool StoreData(RegisterModel modelObject)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "INSERT INTO UserDetails(USERNAME,PASSWORD,PhoneNo) VALUES('" + modelObject.userName + "','" + modelObject.password + "','" + modelObject.phoneNo + "'); ";
            try
            {
                command.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                con.Close();
                return false;
            }
        }

        /// <summary>
        /// a method to return password if details provided are correct
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        public string GetPassword(ForgotPasswordModel modelObject)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "select USERNAME,PASSWORD,PhoneNo from UserDetails where USERNAME='" + modelObject.userName + "';";
            command.ExecuteNonQuery();
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    if (modelObject.phoneNo == reader[2].ToString())
                    {
                        string temp = reader[1].ToString();
                        con.Close();
                        return temp;
                    }
                    else
                    {
                        con.Close();
                        return null;
                    }
                }

            }
            con.Close();
            return null;
        }

        /// <summary>
        /// A method to verify password and logIn the user
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        public bool LogInCheck(LogInModel modelObject)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandText = "select USERNAME,PASSWORD from UserDetails where USERNAME='" + modelObject.userName + "';";
            command.ExecuteNonQuery();
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    if (modelObject.password == reader[1].ToString())
                    {
                        con.Close();
                        return true;
                    }

                }
            }
            con.Close();
            return false;
        }
    }
}
