import ship from 'shipping.js';

ship();