function getMaxSalary(band) {
    return 100000;
}
function getMinSalary(band) {
    return 30000;
}
//# sourceMappingURL=PayBand.js.map