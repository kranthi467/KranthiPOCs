declare function require(path: string): any;
declare const webpack: {
  ENV: string
};
