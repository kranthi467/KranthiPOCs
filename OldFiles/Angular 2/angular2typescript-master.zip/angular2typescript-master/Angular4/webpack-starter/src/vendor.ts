import 'zone.js/dist/zone';
import './polyfills';

import '@angular/http';
import '@angular/router';
import '@angular/core';
import '@angular/common';

// RxJS - comment it out if not using or import specific functions
//import 'rxjs';

// Other vendor libraries
