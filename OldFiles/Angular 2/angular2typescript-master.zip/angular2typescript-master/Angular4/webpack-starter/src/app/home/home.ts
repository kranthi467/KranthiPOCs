import { Component } from '@angular/core';

@Component({
  selector: 'my-home',
  styleUrls: ['home.css' ],
  templateUrl: 'home.html'
})
export class Home {}
