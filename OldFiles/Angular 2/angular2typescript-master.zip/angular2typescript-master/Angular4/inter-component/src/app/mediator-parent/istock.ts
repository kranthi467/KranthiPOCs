export interface IStock {
  stockSymbol: string;
  bidPrice: number;
}
