export interface IPriceQuote {
  stockSymbol: string;
  lastPrice: number;
}
