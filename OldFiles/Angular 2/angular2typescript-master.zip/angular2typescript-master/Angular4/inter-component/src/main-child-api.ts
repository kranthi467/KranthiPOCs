import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/childapi/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
