import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/projection/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
