import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/mediator-service-subject/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
