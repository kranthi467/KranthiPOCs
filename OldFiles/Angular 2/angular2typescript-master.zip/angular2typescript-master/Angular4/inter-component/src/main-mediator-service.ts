import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/mediator-service/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
