import { Component } from '@angular/core';

@Component({
  selector: 'auction-footer',
  templateUrl: 'footer.component.html'
})
export class FooterComponent {}
