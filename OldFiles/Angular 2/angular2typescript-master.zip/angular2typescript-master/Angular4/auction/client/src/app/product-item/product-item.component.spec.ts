/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ProductItemComponent } from './product-item.component';

describe('Component: ProductItem', () => {
  it('should create an instance', () => {
    expect(true).toBeTruthy();
  });
});
