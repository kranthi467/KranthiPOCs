/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SearchComponent } from './search.component';

describe('Component: Search', () => {
  it('should create an instance', () => {
    expect(true).toBeTruthy();
  });
});
