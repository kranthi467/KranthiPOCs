import { Component } from '@angular/core';

@Component({
  moduleId: module.id.replace('jscode', 'app'),
  selector: 'main-com',
  templateUrl: 'maincontent.component.html'
})

export class MainComponent { }