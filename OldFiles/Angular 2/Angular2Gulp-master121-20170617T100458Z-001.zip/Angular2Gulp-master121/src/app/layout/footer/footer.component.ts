import { Component } from '@angular/core';

@Component({
  moduleId: module.id.replace('jscode', 'app'),
  selector: 'footer-com',
  templateUrl: 'footer.component.html'
})

export class FooterComponent { }