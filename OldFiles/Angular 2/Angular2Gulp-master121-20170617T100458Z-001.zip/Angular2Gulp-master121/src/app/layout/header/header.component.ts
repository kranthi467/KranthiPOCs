import { Component } from '@angular/core';

@Component({
  moduleId: module.id.replace('jscode', 'app'),
  selector: 'header-com',
  templateUrl: 'header.component.html'
})

export class HeaderComponent { }