import { Component } from '@angular/core';

@Component({
    template: `<h4>Home </h4>`
})

export class HomeComponent { }
