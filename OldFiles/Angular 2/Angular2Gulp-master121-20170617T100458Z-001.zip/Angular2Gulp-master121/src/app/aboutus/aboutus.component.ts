import { Component } from '@angular/core';

@Component({
  template: `<h4>About Us </h4>`
})

export class AboutUsComponent  {  }