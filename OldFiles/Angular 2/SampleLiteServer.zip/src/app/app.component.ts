import { Component } from '@angular/core';

@Component({
  moduleId: module.id.replace('jscode', 'app'),
  selector: 'my-app',
  templateUrl: 'app.component.html'
})

export class AppComponent { }
